import os
from supabase import create_client
from dotenv import load_dotenv

load_dotenv()

supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_KEY")
supabase = create_client(supabase_url, supabase_key)

def get_users():
    response = supabase.table('users').select('*').execute()
    return response.data

def get_user_by_username(username):
    response = supabase.table('users').select('*').eq('username', username).execute()
    return response.data[0] if response.data else None

def get_user_by_slack_id(slack_id):
    response = supabase.table('users').select('*').eq('slack_id', slack_id).execute()
    return response.data[0] if response.data else None

def create_user(username, slack_id=None, slack_email=None, is_admin=False, is_superadmin=False):
    data = {
        'username': username,
        'slack_id': slack_id,
        'slack_email': slack_email,
        'is_admin': is_admin,
        'superadmin': is_superadmin
    }
    response = supabase.table('users').insert(data).execute()
    return response.data[0] if response.data else None

def update_user(username, data):
    response = supabase.table('users').update(data).eq('username', username).execute()
    return response.data[0] if response.data else None

def is_superadmin(username):
    user = get_user_by_username(username)
    return user and user.get('superadmin', False)

def is_admin(username):
    user = get_user_by_username(username)
    return user and (user.get('is_admin', False) or user.get('superadmin', False))

def get_admin_keys():
    response = supabase.table('admin_keys').select('*').execute()
    return response.data

def get_admin_key(key):
    response = supabase.table('admin_keys').select('*').eq('key', key).execute()
    return response.data[0] if response.data else None

def add_admin_key(name, key, generated_by, generated_at):
    data = {
        'name': name,
        'key': key,
        'generated_by': generated_by,
        'generated_at': generated_at
    }
    response = supabase.table('admin_keys').insert(data).execute()
    return response.data

def revoke_admin_key(key):
    response = supabase.table('admin_keys').delete().eq('key', key).execute()
    return response.data

def promote_to_superadmin(username):
    response = supabase.table('users').update({'superadmin': True, 'is_admin': True}).eq('username', username).execute()
    return response.data

def promote_to_admin(username):
    response = supabase.table('users').update({'is_admin': True, 'superadmin': False}).eq('username', username).execute()
    return response.data

def demote_user(username):
    response = supabase.table('users').update({'is_admin': False, 'superadmin': False}).eq('username', username).execute()
    return response.data

def get_activity_logs():
    response = supabase.table('activity_logs').select('*').order('timestamp', desc=True).execute()
    return response.data

def add_activity_log(username, action, details=None):
    data = {
        'username': username,
        'action': action,
        'details': details,
        'timestamp': 'now()'
    }
    response = supabase.table('activity_logs').insert(data).execute()
    return response.data

def init_invites_table():
    """Initialize the invites table"""
    conn = sqlite3.connect('database.db')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS invites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            invited_by TEXT NOT NULL,
            invite_code TEXT UNIQUE NOT NULL,
            created_at TEXT NOT NULL,
            used_at TEXT,
            used_by TEXT,
            is_used BOOLEAN DEFAULT FALSE
        )
    ''')
    conn.commit()
    conn.close()

def create_invite(email, invited_by):
    """Create a new invite for an email"""
    invite_code = secrets.token_urlsafe(32)
    created_at = datetime.now().isoformat()
    
    conn = sqlite3.connect('database.db')
    try:
        conn.execute('''
            INSERT INTO invites (email, invited_by, invite_code, created_at)
            VALUES (?, ?, ?, ?)
        ''', (email, invited_by, invite_code, created_at))
        conn.commit()
        return invite_code
    except sqlite3.IntegrityError:
        # Email already has an invite
        return None
    finally:
        conn.close()

def get_pending_invite(email):
    """Get a pending (unused) invite for an email"""
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    
    cursor = conn.execute('''
        SELECT * FROM invites 
        WHERE email = ? AND is_used = FALSE
    ''', (email,))
    
    invite = cursor.fetchone()
    conn.close()
    
    return dict(invite) if invite else None

def consume_invite(email, used_by):
    """Mark an invite as used"""
    used_at = datetime.now().isoformat()
    
    conn = sqlite3.connect('database.db')
    conn.execute('''
        UPDATE invites 
        SET is_used = TRUE, used_at = ?, used_by = ?
        WHERE email = ? AND is_used = FALSE
    ''', (used_at, used_by, email))
    conn.commit()
    conn.close()

def get_all_invites():
    """Get all invites for admin view"""
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    
    cursor = conn.execute('''
        SELECT * FROM invites 
        ORDER BY created_at DESC
    ''')
    
    invites = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return invites

def revoke_invite(email):
    """Revoke (delete) an unused invite"""
    conn = sqlite3.connect('database.db')
    cursor = conn.execute('''
        DELETE FROM invites 
        WHERE email = ? AND is_used = FALSE
    ''', (email,))
    
    rows_deleted = cursor.rowcount
    conn.commit()
    conn.close()
    
    return rows_deleted > 0